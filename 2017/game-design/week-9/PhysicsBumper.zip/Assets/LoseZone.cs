﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoseZone : MonoBehaviour
{
	void OnTriggerEnter2D(Collider2D other)
	{
		// play win sound
		Debug.Log("LOSE");
		GetComponent<AudioSource>().Play();
	}
}
