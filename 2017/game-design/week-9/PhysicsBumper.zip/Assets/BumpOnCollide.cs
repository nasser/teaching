﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BumpOnCollide : MonoBehaviour {
	void OnCollisionEnter2D(Collision2D coll)
	{
		GetComponent<Rigidbody2D>().AddForce(Vector2.up * 200);
		//GetComponent<Rigidbody2D>().AddTorque(10);
		GetComponent<AudioSource>().Play();
	}
}
