﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpingEnemy : MonoBehaviour
{
	public float speed = 5;

	// waiting, rising, falling

	void Start()
	{
		StartCoroutine(JumpAiCoro());
	}

	IEnumerator JumpAiCoro()
	{
		// repeat
		while (true)
		{
			// wait for 2 seconds
			yield return new WaitForSeconds(2);

			// rise for 2 seconds
			float timeWeStartedRising = Time.time;
			while (Time.time < timeWeStartedRising + 2)
			{
				Rise();
				yield return null;
			}

			// fall for 2 seconds
			float timeWeStartedFalling = Time.time;
			while (Time.time < timeWeStartedFalling + 2)
			{
				Fall();
				yield return null;
			}
		}
	}

	void Rise()
	{
		transform.position += speed * transform.up * Time.deltaTime;
	}

	void Fall()
	{
		transform.position -= speed * transform.up * Time.deltaTime;
	}

}
