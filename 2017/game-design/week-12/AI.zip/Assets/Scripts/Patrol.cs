﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol : MonoBehaviour
{
	public Transform[] patrolPositions;
	public GameObject player;
	public float patrolSpeed;
	public float chaseSpeed;
	public float chaseDistance;

	void Start()
	{
		StartCoroutine(PatrolCoro());
	}

	bool ShouldChasePlayer()
	{
		return Vector3.Distance(transform.position, player.transform.position) < chaseDistance;
	}

	IEnumerator PatrolCoro()
	{
		int currentIndex = 0;
		while (true)
		{
			if (ShouldChasePlayer())
			{
				yield return StartCoroutine(ChasePlayerCoro());
			}
			else
			{
				Vector3 nextPosition = patrolPositions[currentIndex].position;
				Vector3 direction = nextPosition - transform.position;
				Vector3 movement = direction.normalized * patrolSpeed * Time.deltaTime;
				transform.position += movement;
				if (direction.magnitude < patrolSpeed * Time.deltaTime)
				{
					currentIndex = currentIndex + 1;
					if (currentIndex >= patrolPositions.Length)
					{
						currentIndex = 0;
					}
				}
				yield return null;
			}
		}
	}

	IEnumerator ChasePlayerCoro()
	{
		while (ShouldChasePlayer())
		{
			Vector3 direction = player.transform.position - transform.position;
			Vector3 movement = direction.normalized * chaseSpeed * Time.deltaTime;
			transform.position += movement;
			yield return null;
		}
	}
}
