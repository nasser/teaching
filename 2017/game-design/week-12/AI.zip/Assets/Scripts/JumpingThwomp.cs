﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpingThwomp : MonoBehaviour
{
	public Transform player;
	public float speed = 5;

	// waiting, rising, falling

	void Start()
	{
		StartCoroutine(JumpAiCoro());
	}

	IEnumerator JumpAiCoro()
	{
		// repeat
		while (true)
		{
			// wait for 2 seconds
			yield return new WaitForSeconds(0.25f);

			// rise for 2 seconds
			float timeWeStartedRising = Time.time;
			while (Time.time < timeWeStartedRising + 0.5f)
			{
				Rise();
				yield return null;
			}

			// fall for 2 seconds
			float timeWeStartedFalling = Time.time;
			while (Time.time < timeWeStartedFalling + 0.5f)
			{
				Fall();
				yield return null;
			}
		}
	}

	void Rise()
	{
		// wait for player to be near us
		float distanceToPlayer = Vector3.Distance(transform.position, player.position);
		transform.position += (speed / distanceToPlayer) * transform.up * Time.deltaTime;
	}

	void Fall()
	{
		// wait for player to be near us
		float distanceToPlayer = Vector3.Distance(transform.position, player.position);
		transform.position -= (speed / distanceToPlayer) * transform.up * Time.deltaTime;
	}
}
