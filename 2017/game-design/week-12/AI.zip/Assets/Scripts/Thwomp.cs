﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Thwomp : MonoBehaviour
{
	public float speed = 5;
	public Transform player;

	// waiting, rising, falling

	void Start()
	{
		StartCoroutine(ThwompCoro());
	}

	IEnumerator ThwompCoro()
	{
		// repeat
		while (true)
		{
			// wait for player to be near us
			float distanceToPlayer = Vector3.Distance(transform.position, player.position);
			while (distanceToPlayer > 5)
			{
				yield return null;
				distanceToPlayer = Vector3.Distance(transform.position, player.position);
			}

			// rise for 2 seconds
			float timeWeStartedRising = Time.time;
			while (Time.time < timeWeStartedRising + 0.5f)
			{
				Rise();
				yield return null;
			}

			// fall for 2 seconds
			float timeWeStartedFalling = Time.time;
			while (Time.time < timeWeStartedFalling + 0.5f)
			{
				Fall();
				yield return null;
			}
			transform.position = new Vector3(transform.position.x, 0, transform.position.z);
		}
	}

	void Rise()
	{
		transform.position += speed * transform.up * Time.deltaTime;
	}

	void Fall()
	{
		transform.position -= speed * transform.up * Time.deltaTime;
	}

}
