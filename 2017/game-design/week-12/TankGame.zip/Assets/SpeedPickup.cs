﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedPickup : MonoBehaviour
{
	public float speed = 2f;
	void OnCollisionEnter2D(Collision2D collision)
	{
		var newPickupData = collision.gameObject.AddComponent<SpeedPickupData>();
		newPickupData.speed = speed;
		Destroy(gameObject);
	}
}