﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopMoving : MonoBehaviour
{
	// assumptions:
	// - the tank has a TankForward component
	public float forHowLong;

	void OnTriggerEnter2D(Collider2D collider)
	{
		StartCoroutine(StopTankMovement(collider.gameObject));
	}

	IEnumerator StopTankMovement(GameObject tank)
	{
		tank.GetComponent<TankForward>().enabled = false;
		yield return new WaitForSeconds(forHowLong);
		tank.GetComponent<TankForward>().enabled = true;
	}
}
