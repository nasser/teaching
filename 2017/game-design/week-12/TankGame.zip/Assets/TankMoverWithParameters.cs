﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankMoverWithParameters : MonoBehaviour
{
	// customization
	// not reuse
	public bool shouldRotate;
	public bool shouldMove;
	public float rotationSpeed;
	public float moveSpeed;

	void Update()
	{
	if (shouldRotate)
			transform.Rotate(0, 0, -1 * rotationSpeed * Input.GetAxis("Horizontal"));

		if (shouldMove)
			transform.position += transform.up * Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;
	}
}
