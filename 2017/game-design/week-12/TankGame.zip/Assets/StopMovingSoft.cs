﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopMovingSoft : MonoBehaviour
{
	public float forHowLong;

	void OnTriggerEnter2D(Collider2D collider)
	{
		StartCoroutine(StopTankMovement(collider.gameObject));
	}

	IEnumerator StopTankMovement(GameObject tank)
	{
		tank.SendMessage("StopMoving", SendMessageOptions.DontRequireReceiver);
		yield return new WaitForSeconds(forHowLong);
		tank.SendMessage("StartMoving", SendMessageOptions.DontRequireReceiver);
	}
}
