﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpInOil : MonoBehaviour
{
	public Vector2 jump;

	void StopMoving()
	{
		GetComponent<Rigidbody2D>().simulated = false;
	}

	void StartMoving()
	{
		GetComponent<Rigidbody2D>().simulated = true;
		GetComponent<Rigidbody2D>().AddForce(jump, ForceMode2D.Impulse);
	}
}
