﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankMover : MonoBehaviour {
	void Update () {
		// assumptions:
		// - gameobject has a transform
		// - project has axes named "Horizontal" and "Vertical"
		// - tank is moved by input
		// - tank moves in y direction
		// - tank rotates at -1 degree per frame in z axis
		// - tank moves forward at 1 unit per second
		// - tank always moves AND rotates
		transform.Rotate(0, 0, -1 * Input.GetAxis("Horizontal"));
		transform.position += transform.up * Input.GetAxis("Vertical") * Time.deltaTime;
	}
}