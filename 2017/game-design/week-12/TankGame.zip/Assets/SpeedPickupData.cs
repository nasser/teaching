﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedPickupData : MonoBehaviour
{
	public float speed;

	void Update()
	{
		transform.position += transform.up * Input.GetAxis("Vertical") * Time.deltaTime * speed;
	}
}
