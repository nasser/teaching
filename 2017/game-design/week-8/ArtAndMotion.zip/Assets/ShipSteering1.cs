﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipSteering1 : MonoBehaviour
{
	public float speed = 10;
	void Update()
	{
		var xAmount = Input.GetAxis("Vertical") * Time.deltaTime * speed;
		var yAmount = Input.GetAxis("Horizontal") * Time.deltaTime * speed;
		transform.Rotate(xAmount, yAmount, 0);
	}
}
