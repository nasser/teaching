﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SideToSide : MonoBehaviour {
	public float speed = 5f;
	public float distance = 5f;

	void Update () {
		transform.position = new Vector3(Mathf.Sin(Time.time * speed) * distance, 0, 0);
	}
}
