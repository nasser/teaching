﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipSteering2 : MonoBehaviour
{
	[Range(0, 1)]
	public float speed;
	void Update()
	{
		// compute a direction to look in
		Vector3 directionToLookIn = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0f) * Time.deltaTime;
		// compute a new rotation quaternion
		transform.rotation = Quaternion.Slerp(Quaternion.FromToRotation(transform.forward, directionToLookIn),
											  transform.rotation,
											  0.9f);
	}
}
