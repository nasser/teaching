﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipFlyer : MonoBehaviour {
	public float speed = 2f;

	void Update () {
		// move the object along its forward axis by speed units every second 
		transform.position += transform.forward * speed * Time.deltaTime;
	}
}
