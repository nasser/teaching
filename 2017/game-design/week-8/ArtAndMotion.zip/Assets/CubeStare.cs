﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeStare : MonoBehaviour {
	public GameObject thingToStareAt;

	void Update () {
		var vectorBetweenUs = transform.position - thingToStareAt.transform.position;
		transform.forward = vectorBetweenUs.normalized;

		if (vectorBetweenUs.magnitude < 5)
		{
			// if the player gets too close, start acting physically
			gameObject.AddComponent<Rigidbody>();
			// and remove this component
			Destroy(this);
		}
	}
}
